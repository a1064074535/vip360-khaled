const { Client, LocalAuth } = require('whatsapp-web.js');
const qrcode = require('qrcode-terminal');
require('dotenv').config();

// Process error handlers
process.on('unhandledRejection', (reason, p) => {
    console.log('Unhandled Rejection at:', p, 'reason:', reason);
});
process.on('uncaughtException', (err) => {
    console.log('Uncaught Exception:', err);
});

let client;

// Service Definitions with Requirements
const services = [
    {
        name: "الضمان الاجتماعي المطور",
        requirements: "لتسجيلك في الضمان الاجتماعي المطور، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. تاريخ الميلاد\n3. رقم الجوال\n4. العنوان الوطني\n5. بيانات الدخل الشهري\n6. الحساب البنكي (الآيبان)"
    },
    {
        name: "حافز",
        requirements: "للتسجيل في حافز، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. المؤهل الدراسي وتاريخ التخرج\n3. رقم الجوال\n4. الحساب البنكي (الآيبان)"
    },
    {
        name: "حساب المواطن",
        requirements: "للتسجيل في حساب المواطن، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. تاريخ الميلاد\n3. رقم الجوال\n4. بيانات الدخل للأسرة\n5. الحساب البنكي (الآيبان)"
    },
    {
        name: "ساند",
        requirements: "للتقديم على ساند (دعم التعطل عن العمل)، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. رقم الجوال\n3. قرار الفصل أو الاستقالة\n4. الحساب البنكي (الآيبان)"
    },
    {
        name: "قياس",
        requirements: "للتسجيل في اختبارات قياس، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. نوع الاختبار المطلوب\n3. المنطقة والمدينة المفضلة للاختبار"
    },
    {
        name: "جدارات",
        requirements: "للتسجيل في منصة جدارات، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. المؤهل العلمي (وثيقة التخرج)\n3. السجل الأكاديمي\n4. الخبرات السابقة (إن وجدت)"
    },
    {
        name: "تمهير",
        requirements: "للتسجيل في برنامج تمهير، يرجى تزويدنا بـ:\n1. الهوية الوطنية\n2. وثيقة التخرج (بكالوريوس أو دبلوم)\n3. رقم الجوال\n4. الحساب البنكي (الآيبان)"
    },
    {
        name: "توطين",
        requirements: "للاستفادة من دعم توطين، يرجى تزويدنا بـ:\n1. بيانات المنشأة (لأصحاب العمل) أو الهوية الوطنية (للأفراد)\n2. العقد الوظيفي\n3. بيانات التأمينات الاجتماعية"
    },
    {
        name: "إنشاء متجر إلكتروني",
        requirements: "لإنشاء متجرك الإلكتروني، يرجى تزويدنا بـ:\n1. اسم المتجر المقترح\n2. نوع النشاط التجاري\n3. الهوية الوطنية (للتوثيق)\n4. رقم الجوال والبريد الإلكتروني"
    },
    {
        name: "دورة التجارة الإلكترونية",
        requirements: "للتسجيل في دورة التجارة الإلكترونية، يرجى تزويدنا بـ:\n1. الاسم الثلاثي\n2. رقم الجوال\n3. المستوى الحالي في التجارة الإلكترونية (مبتدئ/متوسط)"
    },
    {
        name: "التدريس من المنزل",
        requirements: "لخدمة التدريس من المنزل، يرجى تزويدنا بـ:\n1. التخصص الدراسي\n2. المراحل الدراسية المستهدفة\n3. الخبرة السابقة (إن وجدت)"
    },
    {
        name: "التسويق الرقمي",
        requirements: "لخدمات التسويق الرقمي، يرجى تزويدنا بـ:\n1. رابط مشروعك أو حسابات التواصل الاجتماعي\n2. الهدف من التسويق (زيادة مبيعات/متابعين)\n3. الميزانية المقترحة (إن وجدت)"
    },
    {
        name: "زيادة المتابعين",
        requirements: "لزيادة المتابعين، يرجى تزويدنا بـ:\n1. رابط الحساب\n2. المنصة (تيك توك، انستقرام، تويتر، إلخ)\n3. العدد المطلوب"
    },
    {
        name: "إعداد السيرة الذاتية",
        requirements: "لإعداد سيرتك الذاتية، يرجى تزويدنا بـ:\n1. المعلومات الشخصية (الاسم، الجوال، الإيميل)\n2. المؤهلات العلمية\n3. الخبرات العملية\n4. المهارات والدورات"
    },
    {
        name: "متابعة التوظيف",
        requirements: "لخدمة متابعة التوظيف، يرجى تزويدنا بـ:\n1. السيرة الذاتية الحالية\n2. المؤهل العلمي\n3. المسميات الوظيفية المستهدفة\n4. المدن المفضلة للعمل"
    }
];

const servicesList = services.map((s, i) => `${i + 1}. ${s.name}`).join('\n');

const initializeClient = () => {
    console.log('Initializing client...');
    
    client = new Client({
        authStrategy: new LocalAuth({
            clientId: 'khaled-bot',
            dataPath: './.auth_new_v3'
        }),
        puppeteer: {
            headless: true,
            args: [
                '--no-sandbox',
                '--disable-setuid-sandbox',
                '--disable-dev-shm-usage',
                '--disable-accelerated-2d-canvas',
                '--no-first-run',
                '--no-zygote',
                '--disable-gpu'
            ],
            dumpio: false
        }
    });

    client.on('qr', (qr) => {
        console.log('Scan this QR with WhatsApp:');
        qrcode.generate(qr, { small: true });
    });

    client.on('ready', () => {
        console.log('✅ Client is ready!');
        
        // Send a startup message to the user
        const userNumber = '966507866885@c.us';
        const startupMessage = `*Bot Updated with Service Requirements*
*تم تحديث البوت بمتطلبات الخدمات*

الأوامر المتاحة / Available Commands:
1. *services* / *خدمات*:
   - عرض قائمة الخدمات الـ 15
   - List the 15 services

2. *test* / *تجربة*:
   - للتحقق من أن البوت يعمل
   - Check if bot is working`;

        client.sendMessage(userNumber, startupMessage).then(() => {
            console.log('✅ Startup message sent to ' + userNumber);
        }).catch(err => {
            console.error('❌ Failed to send startup message:', err);
        });
    });

    client.on('authenticated', () => console.log('✅ Authenticated (session saved)'));
    client.on('auth_failure', (msg) => console.error('❌ Auth failure:', msg));
    
    client.on('disconnected', (reason) => {
        console.log('⚠️ Disconnected:', reason);
        // Destroy and re-initialize
        try {
            client.destroy();
        } catch (error) {
            console.error('Error destroying client:', error);
        }
        client = null;
        console.log('Re-initializing client in 5 seconds...');
        setTimeout(initializeClient, 5000);
    });

    client.on('message', message => {
        console.log(`Message received from ${message.from}: ${message.body}`);
        
        const msgBody = message.body.toLowerCase().trim();

        if (msgBody === 'services' || msgBody === 'خدمات' || msgBody === 'الخدمات') {
            message.reply(`*قائمة الخدمات المتاحة:*\n\n${servicesList}\n\n*يرجى إرسال رقم الخدمة المطلوبة لمعرفة التفاصيل والمتطلبات.*\n\nلزيارة الموقع: https://genuine-yeot-a5e6eb.netlify.app/`);
        } else if (msgBody === '!ping' || msgBody === 'ping') {
            message.reply('pong');
        } else if (msgBody === 'hello' || msgBody === 'hi' || msgBody === 'test' || msgBody === 'تجربة') {
            message.reply('Bot is working! / البوت يعمل بنجاح!\nأرسل "خدمات" لعرض القائمة.');
        } else {
            // Check if message is a number 1-15
            const serviceIndex = parseInt(msgBody) - 1;
            
            if (!isNaN(serviceIndex) && serviceIndex >= 0 && serviceIndex < services.length) {
                const selectedService = services[serviceIndex];
                const replyMsg = `✅ *لقد اخترت خدمة: ${selectedService.name}*\n\n📋 *المتطلبات لإتمام الخدمة:*\n${selectedService.requirements}\n\nيرجى تزويدنا بهذه البيانات هنا أو عبر الرابط:\nhttps://genuine-yeot-a5e6eb.netlify.app/`;
                message.reply(replyMsg);
            } 
            // Also check if user typed the exact service name
            else {
                const foundService = services.find(s => s.name === message.body || s.name.includes(message.body));
                if (foundService && message.body.length > 3) { // Length check to avoid matching short common words
                    const replyMsg = `✅ *لقد اخترت خدمة: ${foundService.name}*\n\n📋 *المتطلبات لإتمام الخدمة:*\n${foundService.requirements}\n\nيرجى تزويدنا بهذه البيانات هنا أو عبر الرابط:\nhttps://genuine-yeot-a5e6eb.netlify.app/`;
                    message.reply(replyMsg);
                }
            }
        }
    });

    client.initialize().catch(err => {
        console.error('Initialization error:', err);
        console.log('Retrying initialization in 5 seconds...');
        setTimeout(initializeClient, 5000);
    });
};

// Start the client
initializeClient();

// Keep the process alive
process.stdin.resume();
setInterval(() => {
    // Heartbeat to keep process alive and monitor status
    // console.log('Heartbeat...'); 
}, 30000);
